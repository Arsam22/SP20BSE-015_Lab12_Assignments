package humanresource;
import java.util.Scanner;
public class Student extends Person implements Association
{
    private int rollNumber;
    private int Semester;
    public Student(String name, String id) 
    {
        super(name, id);
    }
    public void associate() 
    {
        Scanner input = new Scanner(System.in);
        System.out.println("Enter Roll Number:");
        this.rollNumber = input.nextInt();
        System.out.println("Enter Semester:");
        this.Semester = input.nextInt();
        input.close();    
    }
     public String toString()
    {
        return "STUDENT\n" + super.toString() + "\nRoll Number: " + rollNumber + "\nSemester: " + Semester;
    }   
}