package humanresource;
public class Runner
{
    public static void main(String[] args)
    {
        HumanResource h1 = new HumanResource();
        h1.add( new Teacher("Ahmed", "0004565") );
        h1.add( new Teacher("Ali", "00004566") );
        h1.add( new Teacher("Umer", "0004567") );
        h1.add( new Student("Ejaz", "0000115") );
        h1.add( new Student("Faiz", "0000116") );
        h1.add( new Student("Daniyal", "0000117") );
        h1.display();
        Association sw = new Student("student", "98998");
        sw.associate();
        Association tw = new Student("teacher", "12345");
        tw.associate();
    }              
}