package humanresource;
import java.util.ArrayList;
public class HumanResource
{
    private ArrayList<Association> resources;
    private Association [] p = new Association [6];
    private int count = 0;
    public HumanResource()
    {
        resources = new ArrayList<>();
    }
    public void add(Association r)
    {
        resources.add(r);
    }
    public boolean delete(String ID)
    {
        for(int i = 0; i<resources.size(); i++)
        {
            if(((Person)resources.get(i)).id == ID)
            {
                resources.remove(i);
                return true;
            }
        }
        return false;
    }
    public void display()
    {
        for(int i = 0; i <resources.size();i++)
        {
            System.out.println();
            System.out.println(i+"-"+resources.get(i).toString());
            System.out.println();
        }
    }
    public String toString()
    {
        return " ";
    }
        private void extend()
    {
        Association[] newPerson = new Association[count+1];
        if(count > 0)
        {
            for(int i=0; i<newPerson.length; i++)
            {
                newPerson[i] = p[i];
            }
            p = newPerson;
        }
    }
}