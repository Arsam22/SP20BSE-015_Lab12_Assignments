package humanresource;
public interface Association 
{
    void associate();    
}